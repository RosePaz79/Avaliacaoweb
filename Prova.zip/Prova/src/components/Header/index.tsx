
import brand from "../../assets/images/brand.gif"

import { Container, Content } from "./styles";

export function Header() {
    return (
        <Container>
            <Content>
                <div className="page-details">
                    <h1>Instituto Federal do Paraná</h1>
                    <h2>IPPR - Campos Cascavel</h2>
                </div>

                <img src={brand} alt="Instituto" />
            </Content>
        </Container>
    );
}