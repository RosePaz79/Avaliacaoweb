import { Board, OrdersContainer } from "./styles";

interface OrdersBoardProps{
    icon: string;
    title: string;
}

export function OrdersBoard(props: OrdersBoardProps) {
    return (
        <Board>
                <header>
                    <span>{props.icon}</span>
                    <strong>{props.title}</strong>
                    <span>(1)</span>
                </header>

                <OrdersContainer>
                    <button type="button">
                        <strong>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum, quod ad minima quisquam in error! Nemo amet eum sint ea doloribus deleniti perspiciatis velit cupiditate? Esse ea nesciunt ipsa dolorem!</strong>
                        <span></span>
                    </button>
                </OrdersContainer>
            </Board>
    );
}

