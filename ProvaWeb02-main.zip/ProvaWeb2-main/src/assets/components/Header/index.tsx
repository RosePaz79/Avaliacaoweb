// import LogoIfpr from "../../assets/images/IfprCascavel.jpg"
import LogoIfpr from "../../images/download.png"
import { Container, Content } from "./styles";

export function Header() {
    return (
        <Container>
            <Content>
                <img className="logo" src={LogoIfpr} alt="AppFood"/>
                <div className="page-details">
                    <h1>IFPR Campos de Cascavel - pr</h1>
                </div>
            </Content>
        </Container>
    );
}